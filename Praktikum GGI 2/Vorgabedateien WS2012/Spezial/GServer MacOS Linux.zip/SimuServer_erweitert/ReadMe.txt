erweiterter SimuServer fuer das Praktikum Informatik 2, WS 2009/10 RWTH Aachen
von Robert Uhl, 2009


versteht zwei zusaetzliche Befehle:

"time zeit"		-	setzt eine double Zeit in der Titelzeile
"message string"	-	oeffnet eine Fehlermeldung mit dem Text string
